import { base44 } from './base44Client';


export const Document = base44.entities.Document;

export const DocumentPermission = base44.entities.DocumentPermission;

export const SavedSearch = base44.entities.SavedSearch;

export const DocumentActivity = base44.entities.DocumentActivity;

export const SharedAccess = base44.entities.SharedAccess;



// auth sdk:
export const User = base44.auth;